/*
  SmartIoT.h - Arduino-ESP8255 library
  Smart IoT Platform
  http://iot-chula.com
*/

#ifndef SMARTIOT_H
#define SMARTIOT_H

#include <ESP8266WiFi.h>
#include "PubSubClient.h" //PubSubClient.h in the same folder

class SmartIoT{
private:
  char* projectKey;
  char* projectSecret;
  char* projectID;
  char* deviceID;
  PubSubClient pubSubClient;
public:
  SmartIoT();
  SmartIoT(Client&);
  void init(char* projectKey, char* projectSecret, char*projectID);
  bool connect(char* deviceID, char* projectKey, char* projectSecret);
  bool publish(char* channel, char* message);
  bool subscribe(char* channel);
  bool connected();
  bool loop();
};
#endif
