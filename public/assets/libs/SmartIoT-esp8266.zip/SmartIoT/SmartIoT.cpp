#include "SmartIoT.h"

SmartIoT::SmartIoT(){
  pubSubClient = PubSubClient();
}

SmartIoT::SmartIoT(Client& client){
  pubSubClient = PubSubClient(client);
  pubSubClient.setServer("iot-chula.com",8080);
}

void SmartIoT::init(char* projectKey, char* projectSecret, char*projectID){
  this->projectKey = projectKey;
  this->projectSecret = projectSecret;
  this->projectID = projectID;
}

bool SmartIoT::connect(char* deviceID, char* projectKey, char* projectSecret){
  this->deviceID = deviceID;
  this->projectKey = projectKey;
  this->projectSecret = projectSecret;
  return pubSubClient.connect(deviceID,projectKey,projectSecret);
}
bool SmartIoT::publish(char* channel, char* message){
  return pubSubClient.publish(channel,message);
}
bool SmartIoT::subscribe(char* channel){
  return pubSubClient.subscribe(channel);
}
bool SmartIoT::connected(){
    return pubSubClient.connected();
}
bool SmartIoT::loop(){
  return pubSubClient.loop();
}
